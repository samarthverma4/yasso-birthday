# Happy Birthday Yasso Ji — Vercel deploy

```
index.html        the whole site
api/wishes.js     shared wish wall API (GET list, POST add, DELETE for moderation)
package.json      one dependency: @upstash/redis
```

## Deploy

1. Push this folder to a GitHub repo and import it in Vercel (Framework preset: **Other**, no build command).
2. In the Vercel project: **Storage → Marketplace → Upstash (Redis) → Create and connect**.
   This adds `KV_REST_API_URL` and `KV_REST_API_TOKEN` to the project automatically.
3. Optional, for removing bad wishes: add an env var `ADMIN_TOKEN` with any long secret.
4. Redeploy.

## How the wall works

- Newest wishes come first. The page shows the first 10; **See N more wishes** loads the rest.
- Each wish: max 70 characters. Each visitor can paint 5 wishes per 10 minutes.
- Up to 5,000 wishes are kept (oldest dropped after that).
- There is no "delete my wishes" button; remove wishes with the admin token below.
- If `/api/wishes` isn't reachable (e.g. the Claude preview), the wall falls back to saving wishes only on that device.

## Removing a wish

Find its `id` from `https://YOUR-SITE.vercel.app/api/wishes?limit=200`, then:

```
curl -X DELETE "https://YOUR-SITE.vercel.app/api/wishes?id=WISH_ID" -H "x-admin-token: YOUR_ADMIN_TOKEN"
```
